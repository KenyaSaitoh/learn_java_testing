package pro.kensait.java.shipping;

/*
 * 顧客種別を表す列挙型
 */
public enum ClientType {
    GENERAL, GOLD, DIAMOND;
}