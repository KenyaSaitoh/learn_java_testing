package pro.kensait.mockito.customer;

/*
 * 顧客種別を表す列挙型
 */
public enum CustomerType {
    GENERAL, GOLD;
}