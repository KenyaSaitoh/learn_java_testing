package pro.kensait.junit5.assertion4;

import org.junit.jupiter.api.Test;

public class ExceptionTest {

    @Test
    void test() throws Exception {
        //throw new Exception();
    }
}