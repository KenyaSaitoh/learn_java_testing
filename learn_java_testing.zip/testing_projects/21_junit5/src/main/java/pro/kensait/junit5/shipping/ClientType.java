package pro.kensait.junit5.shipping;

/*
 * 顧客種別を表す列挙型
 */
public enum ClientType {
    GENERAL, GOLD, DIAMOND;
}