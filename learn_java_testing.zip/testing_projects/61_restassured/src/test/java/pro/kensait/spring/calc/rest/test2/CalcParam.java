package pro.kensait.spring.calc.rest.test2;

/*
 * 計算処理のパラメータ
 */
public record CalcParam (
        // パラメータ1
        Double param1,
        // パラメータ2
        Double param2) {
}